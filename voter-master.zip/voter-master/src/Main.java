public class Main {
    public static void main(String[] args) {
        ElectionHandler e = new ElectionHandler();
        e.start();
    }
}